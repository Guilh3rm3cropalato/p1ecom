import { hash } from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { UserRole } from "@prisma/client";

async function main() {
  const adminEmail = "admin@bling-commerce.dev";
  const adminPassword = await hash("Admin123!", 10);

  await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      name: "Admin",
      passwordHash: adminPassword,
      role: UserRole.ADMIN
    }
  });

  console.log("Seed concluído com sucesso ✅");
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => prisma.$disconnect());

