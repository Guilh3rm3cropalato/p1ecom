import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
    "./src/lib/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eef2ff",
          100: "#dbe5ff",
          200: "#b1c4ff",
          300: "#809eff",
          400: "#4f78ff",
          500: "#1e52ff",
          600: "#0037d6",
          700: "#0027a3",
          800: "#001870",
          900: "#000840"
        }
      }
    }
  },
  plugins: [require("tailwindcss-animate")]
};

export default config;

