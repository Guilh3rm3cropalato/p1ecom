"use client";

import { useTransition } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const SyncProductsButton = () => {
  const [isPending, startTransition] = useTransition();

  const sync = () => {
    startTransition(async () => {
      try {
        const res = await fetch("/api/bling/products", { method: "POST" });
        if (!res.ok) throw new Error("Erro");
        toast.success("Sincronização iniciada!");
      } catch (error) {
        console.error(error);
        toast.error("Falha ao sincronizar");
      }
    });
  };

  return (
    <Button onClick={sync} disabled={isPending}>
      Sincronizar com Bling
    </Button>
  );
};

