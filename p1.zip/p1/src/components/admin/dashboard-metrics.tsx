type Metric = {
  label: string;
  value: string;
  description: string;
};

export const DashboardMetrics = ({ metrics }: { metrics: Metric[] }) => (
  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
    {metrics.map((metric) => (
      <div key={metric.label} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <p className="text-sm text-slate-500">{metric.label}</p>
        <p className="mt-2 text-2xl font-semibold text-slate-900">{metric.value}</p>
        <p className="text-xs text-slate-400">{metric.description}</p>
      </div>
    ))}
  </div>
);

