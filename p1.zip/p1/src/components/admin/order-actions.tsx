"use client";

import { useTransition } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type Props = {
  orderId: string;
};

export const OrderActions = ({ orderId }: Props) => {
  const [isPending, startTransition] = useTransition();

  const run = (endpoint: string, payload: Record<string, unknown>, successMessage: string) => {
    startTransition(async () => {
      try {
        const res = await fetch(endpoint, { method: "POST", body: JSON.stringify(payload) });
        if (!res.ok) throw new Error("Erro");
        toast.success(successMessage);
      } catch (error) {
        console.error(error);
        toast.error("Falha ao executar ação");
      }
    });
  };

  return (
    <div className="flex flex-wrap gap-2">
      <Button
        variant="outline"
        size="sm"
        disabled={isPending}
        onClick={() => run("/api/bling/orders", { orderId, status: "SHIPPED" }, "Status atualizado!")}
      >
        Atualizar status
      </Button>
      <Button
        variant="outline"
        size="sm"
        disabled={isPending}
        onClick={() => run("/api/bling/nfe", { orderId }, "NFe gerada!")}
      >
        Gerar NFe
      </Button>
      <Button
        variant="outline"
        size="sm"
        disabled={isPending}
        onClick={() => run("/api/bling/shipping", { orderId }, "Etiqueta gerada!")}
      >
        Gerar etiqueta
      </Button>
    </div>
  );
};

