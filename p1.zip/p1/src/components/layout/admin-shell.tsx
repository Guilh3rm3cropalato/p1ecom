import Link from "next/link";
import { ReactNode } from "react";
import { cn } from "@/lib/utils";

const links = [
  { href: "/admin/dashboard", label: "Dashboard" },
  { href: "/admin/products", label: "Produtos" },
  { href: "/admin/orders", label: "Pedidos" },
  { href: "/admin/customers", label: "Clientes" }
];

export const AdminShell = ({ children, title }: { children: ReactNode; title: string }) => (
  <div className="flex h-screen bg-slate-50">
    <aside className="hidden w-64 flex-col border-r border-slate-200 bg-white p-6 md:flex">
      <h2 className="mb-6 text-lg font-semibold text-brand-600">Painel Bling</h2>
      <nav className="flex flex-col gap-2">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={cn(
              "rounded-md px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100"
            )}
          >
            {link.label}
          </Link>
        ))}
      </nav>
    </aside>
    <main className="flex flex-1 flex-col overflow-y-auto">
      <header className="border-b border-slate-200 bg-white px-6 py-4">
        <h1 className="text-xl font-semibold text-slate-900">{title}</h1>
      </header>
      <section className="flex-1 overflow-y-auto p-6">{children}</section>
    </main>
  </div>
);

