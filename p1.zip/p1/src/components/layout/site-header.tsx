import Link from "next/link";
import { CartButton } from "@/components/store/cart-button";

export const SiteHeader = () => (
  <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur">
    <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
      <Link href="/" className="text-xl font-semibold text-brand-600">
        BlingCommerce
      </Link>
      <nav className="flex items-center gap-6 text-sm font-medium text-slate-700">
        <Link href="/account">Minha conta</Link>
        <Link href="/admin/login">Admin</Link>
        <CartButton />
      </nav>
    </div>
  </header>
);

