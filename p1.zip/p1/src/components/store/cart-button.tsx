"use client";

import Link from "next/link";
import { ShoppingCart } from "lucide-react";
import { useCartStore } from "./cart-store";
import { Button } from "@/components/ui/button";

export const CartButton = () => {
  const items = useCartStore((state) => state.items);
  const count = items.reduce((total, item) => total + item.quantity, 0);

  return (
    <Button variant="outline" size="sm" asChild>
      <Link href="/checkout" className="flex items-center gap-2">
        <ShoppingCart className="h-4 w-4" />
        Carrinho
        {count > 0 && (
          <span className="rounded-full bg-brand-600 px-2 py-0.5 text-xs text-white">
            {count}
          </span>
        )}
      </Link>
    </Button>
  );
};

