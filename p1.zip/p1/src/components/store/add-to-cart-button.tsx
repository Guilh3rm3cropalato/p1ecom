"use client";

import { Button } from "@/components/ui/button";
import { useCartStore } from "./cart-store";

type Props = {
  productId: string;
  name: string;
  price: number;
  image?: string | null;
};

export const AddToCartButton = ({ productId, name, price, image }: Props) => {
  const addItem = useCartStore((state) => state.addItem);

  return (
    <Button
      className="w-full"
      onClick={() =>
        addItem({
          id: productId,
          name,
          price,
          image,
          quantity: 1
        })
      }
    >
      Adicionar ao carrinho
    </Button>
  );
};

