"use client";

import { useState, useTransition } from "react";
import { useCartStore } from "./cart-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatCurrency } from "@/lib/utils";
import { toast } from "sonner";

type FreightResult = {
  servicos: Array<{ servico: string; valor: number; prazo: number }>;
};

export const CheckoutClient = () => {
  const { items, clear } = useCartStore();
  const [customer, setCustomer] = useState({ name: "", email: "", document: "" });
  const [zip, setZip] = useState("");
  const [freight, setFreight] = useState<FreightResult | null>(null);
  const [isPending, startTransition] = useTransition();

  const subtotal = items.reduce((total, item) => total + item.price * item.quantity, 0);
  const shippingCost = freight?.servicos[0]?.valor ?? 0;
  const total = subtotal + shippingCost;

  const requestFreight = () => {
    startTransition(async () => {
      try {
        const response = await fetch("/api/bling/shipping", {
          method: "POST",
          body: JSON.stringify({
            cepOrigem: "01001000",
            cepDestino: zip,
            peso: 1,
            valorDeclarado: subtotal,
            servicos: ["Correios"]
          })
        });
        if (!response.ok) throw new Error("Falha no cálculo de frete");
        const data = (await response.json()) as FreightResult;
        setFreight(data);
      } catch (error) {
        console.error(error);
        toast.error("Não foi possível calcular o frete.");
      }
    });
  };

  const finalizeOrder = () => {
    startTransition(async () => {
      try {
        const response = await fetch("/api/checkout", {
          method: "POST",
          body: JSON.stringify({
            customer,
            shipping: { zip, service: freight?.servicos[0] },
            items
          })
        });
        if (!response.ok) throw new Error("Erro ao finalizar");
        const data = await response.json();
        toast.success(`Pedido ${data.orderId} criado com sucesso!`);
        clear();
      } catch (error) {
        console.error(error);
        toast.error("Erro ao finalizar pedido");
      }
    });
  };

  return (
    <div className="grid gap-8 md:grid-cols-2">
      <section className="rounded-xl border border-slate-200 bg-white p-6">
        <h2 className="text-lg font-semibold text-slate-900">Dados do cliente</h2>
        <div className="mt-4 space-y-4">
          <Input placeholder="Nome completo" value={customer.name} onChange={(e) => setCustomer({ ...customer, name: e.target.value })} />
          <Input placeholder="E-mail" value={customer.email} onChange={(e) => setCustomer({ ...customer, email: e.target.value })} />
          <Input placeholder="CPF/CNPJ" value={customer.document} onChange={(e) => setCustomer({ ...customer, document: e.target.value })} />
          <div className="flex gap-2">
            <Input placeholder="CEP" value={zip} onChange={(e) => setZip(e.target.value)} />
            <Button type="button" onClick={requestFreight} disabled={!zip || isPending}>
              Calcular frete
            </Button>
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-200 bg-white p-6">
        <h2 className="text-lg font-semibold text-slate-900">Resumo</h2>
        <div className="mt-4 space-y-3">
          {items.map((item) => (
            <div key={item.id} className="flex items-center justify-between text-sm text-slate-600">
              <span>
                {item.name} x {item.quantity}
              </span>
              <span>{formatCurrency(item.price * item.quantity)}</span>
            </div>
          ))}
          <div className="flex items-center justify-between text-sm font-medium text-slate-700">
            <span>Subtotal</span>
            <span>{formatCurrency(subtotal)}</span>
          </div>
          <div className="flex items-center justify-between text-sm text-slate-600">
            <span>Frete</span>
            <span>{freight ? formatCurrency(shippingCost) : "Calcule o frete"}</span>
          </div>
          <div className="flex items-center justify-between text-lg font-semibold text-slate-900">
            <span>Total</span>
            <span>{formatCurrency(total)}</span>
          </div>
        </div>
        <Button className="mt-6 w-full" disabled={items.length === 0 || isPending} onClick={finalizeOrder}>
          Finalizar pedido
        </Button>
      </section>
    </div>
  );
};

