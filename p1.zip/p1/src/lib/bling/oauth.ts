import axios from "axios";
import { addSeconds, isAfter } from "date-fns";
import { prisma } from "@/lib/prisma";
import { requiredEnv } from "@/lib/utils";

const BLING_OAUTH_URL = "https://www.bling.com.br/Api/v3/oauth/token";

export type OAuthTokenResponse = {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  scope?: string;
};

export const buildAuthorizationUrl = () => {
  const clientId = requiredEnv("BLING_CLIENT_ID");
  const redirectUri = requiredEnv("BLING_REDIRECT_URI");

  const params = new URLSearchParams({
    response_type: "code",
    client_id: clientId,
    redirect_uri: redirectUri,
    scope: "read write"
  });

  return `https://www.bling.com.br/Api/v3/oauth/authorize?${params.toString()}`;
};

export const exchangeCodeForToken = async (code: string) => {
  const clientId = requiredEnv("BLING_CLIENT_ID");
  const clientSecret = requiredEnv("BLING_CLIENT_SECRET");
  const redirectUri = requiredEnv("BLING_REDIRECT_URI");

  const { data } = await axios.post<OAuthTokenResponse>(
    BLING_OAUTH_URL,
    new URLSearchParams({
      grant_type: "authorization_code",
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri
    }),
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      }
    }
  );

  return data;
};

export const refreshAccessToken = async (refreshToken: string) => {
  const clientId = requiredEnv("BLING_CLIENT_ID");
  const clientSecret = requiredEnv("BLING_CLIENT_SECRET");

  const { data } = await axios.post<OAuthTokenResponse>(
    BLING_OAUTH_URL,
    new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken,
      client_id: clientId,
      client_secret: clientSecret
    }),
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      }
    }
  );

  return data;
};

export const persistToken = async (token: OAuthTokenResponse) => {
  const expiresAt = addSeconds(new Date(), token.expires_in - 60);

  return prisma.blingAuthToken.upsert({
    where: { id: "global" },
    update: {
      accessToken: token.access_token,
      refreshToken: token.refresh_token,
      scope: token.scope,
      expiresAt
    },
    create: {
      id: "global",
      accessToken: token.access_token,
      refreshToken: token.refresh_token,
      scope: token.scope,
      expiresAt
    }
  });
};

export const getValidToken = async () => {
  const token = await prisma.blingAuthToken.findUnique({
    where: { id: "global" }
  });

  if (!token) {
    throw new Error("Token do Bling não foi configurado.");
  }

  if (isAfter(new Date(), token.expiresAt)) {
    const refreshed = await refreshAccessToken(token.refreshToken);
    return persistToken(refreshed);
  }

  return token;
};

