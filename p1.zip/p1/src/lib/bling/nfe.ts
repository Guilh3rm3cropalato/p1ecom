import { prisma } from "@/lib/prisma";
import { blingRequest } from "./client";
import { NFeStatus } from "@prisma/client";

export const issueInvoice = async (orderId: string) => {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order?.blingId) throw new Error("Pedido sem integração Bling");

  const data = await blingRequest<{ data: { id: number; status: string } }>({
    url: "/nfe",
    method: "POST",
    data: { pedidoId: order.blingId }
  });

  return prisma.nFe.upsert({
    where: { orderId },
    update: {
      status: data.data.status as NFeStatus
    },
    create: {
      orderId,
      status: data.data.status as NFeStatus
    }
  });
};

export const fetchInvoiceStatus = async (nfeId: string) => {
  const nfe = await prisma.nFe.findUnique({ where: { id: nfeId } });
  if (!nfe) throw new Error("NFe não encontrada");

  const data = await blingRequest<{ data: { status: string; numero: string; acesso: string } }>({
    url: `/nfe/${nfe.id}`,
    method: "GET"
  });

  return prisma.nFe.update({
    where: { id: nfeId },
    data: {
      status: data.data.status as NFeStatus,
      number: data.data.numero,
      accessKey: data.data.acesso
    }
  });
};

export const downloadInvoiceFiles = async (nfeId: string) => {
  const nfe = await prisma.nFe.findUnique({ where: { id: nfeId } });
  if (!nfe) throw new Error("NFe não encontrada");

  const data = await blingRequest<{ data: { pdf: string; xml: string } }>({
    url: `/nfe/${nfe.id}/download`,
    method: "GET"
  });

  return prisma.nFe.update({
    where: { id: nfeId },
    data: {
      pdfUrl: data.data.pdf,
      xmlUrl: data.data.xml
    }
  });
};

