import { prisma } from "@/lib/prisma";
import { blingRequest } from "./client";
import { ShipmentStatus } from "@prisma/client";

export type FreightRequest = {
  cepOrigem: string;
  cepDestino: string;
  peso: number;
  valorDeclarado: number;
  servicos: string[];
};

export type FreightResponse = {
  servicos: Array<{
    servico: string;
    valor: number;
    prazo: number;
  }>;
};

export const calculateFreight = async (input: FreightRequest) => {
  return blingRequest<FreightResponse>({
    url: "/logisticas/frete/calcular",
    method: "POST",
    data: input
  });
};

export const createShippingLabel = async (orderId: string) => {
  const order = await prisma.order.findUnique({
    where: { id: orderId }
  });

  if (!order?.blingId) throw new Error("Pedido não sincronizado no Bling");

  const data = await blingRequest<{
    data: { etiqueta: string; tracking: string; servico: string; valor: number };
  }>({
    url: `/logisticas/pedidos/${order.blingId}/etiqueta`,
    method: "POST"
  });

  return prisma.shipment.upsert({
    where: { orderId },
    update: {
      trackingCode: data.data.tracking,
      labelUrl: data.data.etiqueta,
      service: data.data.servico,
      cost: data.data.valor
    },
    create: {
      orderId,
      carrier: "Correios",
      service: data.data.servico,
      trackingCode: data.data.tracking,
      labelUrl: data.data.etiqueta,
      cost: data.data.valor
    }
  });
};

export const trackShipment = async (trackingCode: string) => {
  return blingRequest({
    url: `/logisticas/rastreamento/${trackingCode}`,
    method: "GET"
  });
};

export const updateShipmentStatus = async (orderId: string, status: ShipmentStatus) => {
  return prisma.shipment.update({
    where: { orderId },
    data: { status }
  });
};

