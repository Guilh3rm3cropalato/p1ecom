import axios, { type AxiosInstance, type AxiosRequestConfig } from "axios";
import { getValidToken } from "./oauth";

const BASE_URL = "https://www.bling.com.br/Api/v3";

const createClient = (accessToken: string): AxiosInstance => {
  const instance = axios.create({
    baseURL: BASE_URL,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    timeout: 10000
  });

  return instance;
};

export const blingRequest = async <T = unknown>(config: AxiosRequestConfig) => {
  const token = await getValidToken();
  const client = createClient(token.accessToken);
  const { data } = await client.request<T>(config);
  return data;
};

