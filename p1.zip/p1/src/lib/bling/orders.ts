import { prisma } from "@/lib/prisma";
import { blingRequest } from "./client";
import { OrderStatus } from "@prisma/client";

export type BlingOrderItem = {
  codigo: string;
  descricao: string;
  quantidade: number;
  valor: number;
};

export type BlingOrderPayload = {
  numero: string;
  situacao: string;
  data: string;
  cliente: {
    nome: string;
    documento: string;
    email: string;
  };
  itens: BlingOrderItem[];
  valor: number;
};

export const createOrderOnBling = async (orderId: string) => {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { items: { include: { product: true } }, user: true }
  });

  if (!order) throw new Error("Pedido não encontrado");

  const shippingData = (order.shippingData as Record<string, any>) ?? {};
  const billingData = (order.billingData as Record<string, any>) ?? {};

  const payload = {
    numero: order.id,
    situacao: order.status,
    data: order.createdAt.toISOString(),
    cliente: {
      nome: order.user?.name ?? "Cliente",
      documento: shippingData.document ?? "",
      email: order.user?.email ?? billingData.email ?? ""
    },
    itens: order.items.map((item) => ({
      codigo: item.product.sku,
      descricao: item.product.name,
      quantidade: item.quantity,
      valor: item.unitPrice
    })),
    valor: order.total
  };

  const data = await blingRequest<{ data: { id: number } }>({
    url: "/pedidos/vendas",
    method: "POST",
    data: payload
  });

  await prisma.order.update({
    where: { id: orderId },
    data: { blingId: String(data.data.id) }
  });

  return data;
};

export const fetchBlingOrders = async () => {
  const data = await blingRequest<{ data: BlingOrderPayload[] }>({
    url: "/pedidos/vendas",
    method: "GET"
  });
  return data.data;
};

export const updateOrderStatus = async (orderId: string, status: OrderStatus) => {
  const order = await prisma.order.findUnique({
    where: { id: orderId }
  });

  if (!order?.blingId) throw new Error("Pedido não sincronizado com o Bling");

  await blingRequest({
    url: `/pedidos/vendas/${order.blingId}`,
    method: "PUT",
    data: { situacao: status }
  });

  return prisma.order.update({
    where: { id: orderId },
    data: { status }
  });
};

