import { prisma } from "@/lib/prisma";
import { blingRequest } from "./client";
import { PaymentStatus } from "@prisma/client";

export type ChargePayload = {
  orderId: string;
  amount: number;
  description?: string;
  dueDate: string;
};

export const createCharge = async ({ orderId, amount, description, dueDate }: ChargePayload) => {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order?.blingId) {
    throw new Error("Pedido não sincronizado com o Bling");
  }

  const payload = {
    pedidoId: order.blingId,
    valor: amount,
    descricao: description,
    dataVencimento: dueDate
  };

  const data = await blingRequest<{ data: { id: number } }>({
    url: "/contas/receber",
    method: "POST",
    data: payload
  });

  await prisma.payment.create({
    data: {
      orderId,
      amount,
      method: "Bling Pay",
      status: PaymentStatus.PENDING,
      externalId: String(data.data.id),
      metadata: payload
    }
  });

  return data;
};

export const confirmPayment = async (paymentId: string) => {
  const payment = await prisma.payment.findUnique({
    where: { id: paymentId }
  });

  if (!payment?.externalId) throw new Error("Pagamento sem referência externa");

  await blingRequest({
    url: `/contas/receber/${payment.externalId}/baixar`,
    method: "POST"
  });

  return prisma.payment.update({
    where: { id: paymentId },
    data: { status: PaymentStatus.CONFIRMED, paidAt: new Date() }
  });
};

