import { prisma } from "@/lib/prisma";
import { blingRequest } from "./client";
import { ProductSyncLog, SyncStatus, SyncType } from "@prisma/client";

export type BlingProduct = {
  id: number;
  codigo: string;
  descricao: string;
  preco: number;
  estoque: number;
  unidade: string;
  imagem?: string;
};

type ProductPayload = {
  data: BlingProduct[];
};

const logSync = async (productId: string | null, type: SyncType, payload: unknown, status: SyncStatus, message?: string) => {
  let log: ProductSyncLog | null = null;
  if (productId) {
    log = await prisma.productSyncLog.create({
      data: {
        productId,
        type,
        payload,
        status,
        message
      }
    });
  }
  return log;
};

export const fetchBlingProducts = async () => {
  const data = await blingRequest<ProductPayload>({ url: "/produtos", method: "GET" });
  return data.data;
};

export const syncProductsFromBling = async () => {
  const remoteProducts = await fetchBlingProducts();

  const results = await Promise.all(
    remoteProducts.map(async (product) => {
      const existing = await prisma.product.findFirst({
        where: { OR: [{ blingId: String(product.id) }, { sku: product.codigo }] }
      });

      let record;
      if (existing) {
        record = await prisma.product.update({
          where: { id: existing.id },
          data: {
            blingId: String(product.id),
            sku: product.codigo,
            name: product.descricao,
            price: product.preco,
            stock: product.estoque,
            imageUrl: product.imagem
          }
        });
      } else {
        record = await prisma.product.create({
          data: {
            blingId: String(product.id),
            sku: product.codigo,
            name: product.descricao,
            price: product.preco,
            stock: product.estoque,
            imageUrl: product.imagem
          }
        });
      }

      await logSync(record.id, SyncType.PRODUCT_PULL, product, SyncStatus.SUCCESS);
      return record;
    })
  );

  return results;
};

export const upsertProductToBling = async (productId: string) => {
  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product) throw new Error("Produto não encontrado");

  const payload = {
    codigo: product.sku,
    descricao: product.name,
    preco: product.price,
    estoque: product.stock,
    unidade: "un",
    situacao: product.active ? "A" : "I"
  };

  const data = await blingRequest<{ data: { id: number } }>({
    url: product.blingId ? `/produtos/${product.blingId}` : "/produtos",
    method: product.blingId ? "PUT" : "POST",
    data: payload
  });

  await prisma.product.update({
    where: { id: productId },
    data: { blingId: String(data.data.id) }
  });

  await logSync(productId, SyncType.PRODUCT_PUSH, payload, SyncStatus.SUCCESS);
  return data;
};

export const updateInventory = async (productId: string, quantity: number) => {
  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product?.blingId) throw new Error("Produto não sincronizado com o Bling");

  const payload = { estoque: quantity };

  const result = await blingRequest({
    url: `/produtos/${product.blingId}/estoque`,
    method: "PUT",
    data: payload
  });

  await prisma.product.update({
    where: { id: productId },
    data: { stock: quantity }
  });

  await logSync(productId, SyncType.INVENTORY, payload, SyncStatus.SUCCESS);
  return result;
};

