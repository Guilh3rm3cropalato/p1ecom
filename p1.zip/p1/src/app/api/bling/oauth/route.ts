import { NextResponse } from "next/server";
import { exchangeCodeForToken, persistToken } from "@/lib/bling/oauth";

export async function POST(request: Request) {
  try {
    const { code } = await request.json();
    if (!code) {
      return NextResponse.json({ error: "Código não informado" }, { status: 400 });
    }

    const token = await exchangeCodeForToken(code);
    await persistToken(token);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Falha na autenticação" }, { status: 500 });
  }
}

