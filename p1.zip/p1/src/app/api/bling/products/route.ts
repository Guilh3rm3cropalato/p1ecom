import { NextResponse } from "next/server";
import { fetchBlingProducts, syncProductsFromBling } from "@/lib/bling/products";

export async function GET() {
  try {
    const products = await fetchBlingProducts();
    return NextResponse.json(products);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro ao buscar produtos" }, { status: 500 });
  }
}

export async function POST() {
  try {
    const result = await syncProductsFromBling();
    return NextResponse.json({ synced: result.length });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro na sincronização" }, { status: 500 });
  }
}

