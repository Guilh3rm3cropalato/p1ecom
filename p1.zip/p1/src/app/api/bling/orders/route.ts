import { NextResponse } from "next/server";
import { updateOrderStatus, fetchBlingOrders } from "@/lib/bling/orders";
import { OrderStatus } from "@prisma/client";

export async function GET() {
  try {
    const orders = await fetchBlingOrders();
    return NextResponse.json(orders);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro ao listar pedidos" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const { orderId, status } = await request.json();
    if (!orderId || !status) {
      return NextResponse.json({ error: "orderId e status são obrigatórios" }, { status: 400 });
    }

    const updated = await updateOrderStatus(orderId, status as OrderStatus);
    return NextResponse.json(updated);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro ao atualizar pedido" }, { status: 500 });
  }
}

