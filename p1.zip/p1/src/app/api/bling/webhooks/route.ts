import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { OrderStatus, NFeStatus, PaymentStatus } from "@prisma/client";

type WebhookPayload = {
  event: "pedido.status" | "nfe.status" | "pagamento.status";
  reference: string;
  status: string;
  metadata?: Record<string, unknown>;
};

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as WebhookPayload;

    switch (payload.event) {
      case "pedido.status":
        await prisma.order.updateMany({
          where: { blingId: payload.reference },
          data: { status: payload.status as OrderStatus }
        });
        break;
      case "nfe.status":
        await prisma.nFe.updateMany({
          where: { order: { blingId: payload.reference } },
          data: { status: payload.status as NFeStatus }
        });
        break;
      case "pagamento.status":
        await prisma.payment.updateMany({
          where: { externalId: payload.reference },
          data: { status: payload.status as PaymentStatus }
        });
        break;
      default:
        console.warn("Evento desconhecido", payload);
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro ao processar webhook" }, { status: 500 });
  }
}

