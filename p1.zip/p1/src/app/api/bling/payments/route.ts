import { NextResponse } from "next/server";
import { createCharge, confirmPayment } from "@/lib/bling/payments";

export async function POST(request: Request) {
  try {
    const { orderId, amount, description, dueDate } = await request.json();
    if (!orderId || !amount || !dueDate) {
      return NextResponse.json({ error: "Dados incompletos" }, { status: 400 });
    }
    const payment = await createCharge({ orderId, amount, description, dueDate });
    return NextResponse.json(payment);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro ao gerar cobrança" }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const { paymentId } = await request.json();
    if (!paymentId) {
      return NextResponse.json({ error: "paymentId é obrigatório" }, { status: 400 });
    }
    const payment = await confirmPayment(paymentId);
    return NextResponse.json(payment);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro ao confirmar pagamento" }, { status: 500 });
  }
}

