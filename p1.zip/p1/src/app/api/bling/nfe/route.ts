import { NextResponse } from "next/server";
import { issueInvoice, downloadInvoiceFiles } from "@/lib/bling/nfe";

export async function POST(request: Request) {
  try {
    const { orderId } = await request.json();
    if (!orderId) {
      return NextResponse.json({ error: "orderId é obrigatório" }, { status: 400 });
    }
    const nfe = await issueInvoice(orderId);
    return NextResponse.json(nfe);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro ao emitir NFe" }, { status: 500 });
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const nfeId = searchParams.get("id");
    if (!nfeId) {
      return NextResponse.json({ error: "id é obrigatório" }, { status: 400 });
    }
    const result = await downloadInvoiceFiles(nfeId);
    return NextResponse.json(result);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro ao baixar NFe" }, { status: 500 });
  }
}

