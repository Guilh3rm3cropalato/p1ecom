import { NextResponse } from "next/server";
import { calculateFreight, createShippingLabel, trackShipment } from "@/lib/bling/shipping";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const tracking = searchParams.get("tracking");
    if (!tracking) {
      return NextResponse.json({ error: "tracking é obrigatório" }, { status: 400 });
    }
    const result = await trackShipment(tracking);
    return NextResponse.json(result);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro ao rastrear envio" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    if (body.cepOrigem) {
      const freight = await calculateFreight(body);
      return NextResponse.json(freight);
    }

    if (body.orderId) {
      const shipment = await createShippingLabel(body.orderId);
      return NextResponse.json(shipment);
    }

    return NextResponse.json({ error: "Payload inválido" }, { status: 400 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro no endpoint de frete" }, { status: 500 });
  }
}

