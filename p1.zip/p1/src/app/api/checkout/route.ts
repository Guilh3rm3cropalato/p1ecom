import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createOrderOnBling } from "@/lib/bling/orders";
import { createCharge } from "@/lib/bling/payments";

type CheckoutItem = {
  id: string;
  quantity: number;
};

export async function POST(request: Request) {
  try {
    const { customer, shipping, items } = await request.json();
    if (!items?.length) {
      return NextResponse.json({ error: "Carrinho vazio" }, { status: 400 });
    }

    const products = await prisma.product.findMany({
      where: { id: { in: items.map((item: CheckoutItem) => item.id) } }
    });

    const enrichedItems = items.map((item: CheckoutItem) => {
      const product = products.find((p) => p.id === item.id);
      if (!product) throw new Error("Produto inválido");
      return {
        productId: product.id,
        quantity: item.quantity,
        unitPrice: product.price
      };
    });

    const subtotal = enrichedItems.reduce((total, item) => total + Number(item.unitPrice) * item.quantity, 0);
    const shippingCost = Number(shipping?.service?.valor ?? 0);
    const total = subtotal + shippingCost;

    const order = await prisma.order.create({
      data: {
        status: "PENDING",
        subtotal,
        shippingCost,
        total,
        shippingData: shipping ?? {},
        billingData: customer ?? {},
        items: {
          create: enrichedItems
        }
      }
    });

    await createOrderOnBling(order.id);
    await createCharge({
      orderId: order.id,
      amount: total,
      description: `Pedido ${order.id}`,
      dueDate: new Date().toISOString().split("T")[0]
    });

    return NextResponse.json({ orderId: order.id });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Erro no checkout" }, { status: 500 });
  }
}

