export { authHandlers as GET, authHandlers as POST } from "@/lib/auth";

